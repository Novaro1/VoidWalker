interface TabData {
  id: string;
  url: string;
  title: string;
}

interface Bookmark {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

interface StoredState {
  tabs: TabData[];
  activeTabId: string | null;
  cloakEnabled: boolean;
  cloakPreset: string | null;
  history: string[];
  bookmarks: Bookmark[];
  privateMode: boolean;
}

const STORAGE_KEY = "voidwalker_state";
const BOOKMARKS_KEY = "voidwalker_bookmarks";
const HISTORY_KEY = "voidwalker_history";

export function saveState(state: StoredState): void {
  try {
    const stateToSave = { ...state };
    if (state.privateMode) {
      stateToSave.history = [];
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
  } catch (e) {
    console.warn("Failed to save state:", e);
  }
}

export function loadState(): StoredState | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (e) {
    console.warn("Failed to load state:", e);
    return null;
  }
}

export function clearState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.warn("Failed to clear state:", e);
  }
}

export function addToHistory(url: string, privateMode: boolean): void {
  if (privateMode) return;
  try {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]") as string[];
    const filtered = history.filter(h => h !== url);
    filtered.unshift(url);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered.slice(0, 50)));
  } catch (e) {
    console.warn("Failed to add to history:", e);
  }
}

export function getHistory(): string[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
  } catch {
    return [];
  }
}

export function clearHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (e) {
    console.warn("Failed to clear history:", e);
  }
}

export function addBookmark(url: string, title: string): Bookmark {
  try {
    const bookmarks = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]") as Bookmark[];
    const id = Math.random().toString(36).substr(2, 9);
    const bookmark: Bookmark = { id, url, title, timestamp: Date.now() };
    bookmarks.unshift(bookmark);
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks));
    return bookmark;
  } catch (e) {
    console.warn("Failed to add bookmark:", e);
    return { id: "", url, title, timestamp: 0 };
  }
}

export function removeBookmark(id: string): void {
  try {
    const bookmarks = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]") as Bookmark[];
    const filtered = bookmarks.filter(b => b.id !== id);
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.warn("Failed to remove bookmark:", e);
  }
}

export function getBookmarks(): Bookmark[] {
  try {
    return JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  } catch {
    return [];
  }
}

export function isBookmarked(url: string): boolean {
  const bookmarks = getBookmarks();
  return bookmarks.some(b => b.url === url);
}