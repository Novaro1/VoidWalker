export const CLOAK_PRESETS = [
  {
    name: "Google Classroom",
    title: "Classes",
    icon: "https://ssl.gstatic.com/classroom/favicon.png"
  },
  {
    name: "Google Drive",
    title: "My Drive - Google Drive",
    icon: "https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_32dp.png"
  },
  {
    name: "Docs",
    title: "Google Docs",
    icon: "https://ssl.gstatic.com/docs/documents/images/kix-favicon7.ico"
  },
  {
    name: "Wikipedia",
    title: "Wikipedia, the free encyclopedia",
    icon: "https://en.wikipedia.org/static/favicon/wikipedia.ico"
  },
  {
    name: "Zoom",
    title: "Zoom Meeting",
    icon: "https://st1.zoom.us/zoom.ico"
  }
];

export function setCloak(presetName: string) {
  const preset = CLOAK_PRESETS.find(p => p.name === presetName);
  if (!preset) return;

  document.title = preset.title;
  
  const link = document.querySelector("link[rel*='icon']") || document.createElement('link');
  (link as HTMLLinkElement).type = 'image/x-icon';
  (link as HTMLLinkElement).rel = 'shortcut icon';
  (link as HTMLLinkElement).href = preset.icon;
  document.getElementsByTagName('head')[0].appendChild(link);
}

export function resetCloak() {
  document.title = "VoidWalker // Unrestricted Access";
  const link = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
  if (link) link.href = "/favicon.png";
}