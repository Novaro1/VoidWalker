export const USER_AGENTS = [
  {
    name: "Chrome (Default)",
    value: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  },
  {
    name: "Safari (macOS)",
    value: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Version/15.0"
  },
  {
    name: "Firefox (Linux)",
    value: "Mozilla/5.0 (X11; Linux x86_64; rv:90.0) Gecko/20100101 Firefox/90.0"
  },
  {
    name: "Edge (Windows)",
    value: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Edg/90.0"
  },
  {
    name: "Mobile Chrome",
    value: "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 Chrome/91.0"
  }
];

export function injectUserAgent(html: string, userAgent: string): string {
  const script = `
    <script>
      Object.defineProperty(navigator, 'userAgent', {
        get: () => '${userAgent}'
      });
    </script>
  `;
  
  if (html.includes("<head>")) {
    return html.replace("<head>", `<head>${script}`);
  }
  return script + html;
}