// List of public CORS proxies to try in order
const PROXY_GATEWAYS = [
  "https://api.allorigins.win/raw?url=",
  "https://corsproxy.io/?",
  "https://api.codetabs.com/v1/proxy?quest="
];

export function normalizeUrl(urlInput: string): string {
  let url = urlInput.trim();
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    url = "https://" + url;
  }
  return url;
}

async function tryFetch(url: string, proxyBase: string): Promise<string> {
  const targetUrl = normalizeUrl(url);
  const encodedUrl = encodeURIComponent(targetUrl);
  // Some proxies handle encoding differently, but standard encoding is safest
  // For corsproxy.io, it's just the url appended
  let proxyUrl = proxyBase + encodedUrl;
  
  if (proxyBase.includes("corsproxy.io")) {
    proxyUrl = proxyBase + targetUrl;
  }

  const response = await fetch(proxyUrl);
  if (!response.ok) throw new Error(`Status ${response.status}`);
  return await response.text();
}

export async function fetchProxyContent(url: string): Promise<string> {
  const targetUrl = normalizeUrl(url);
  let lastError: Error | null = null;

  // Try each proxy in sequence
  for (const gateway of PROXY_GATEWAYS) {
    try {
      let html = await tryFetch(targetUrl, gateway);
      
      // Client-side rewriting
      const baseTag = `<base href="${targetUrl}">`;
      if (html.includes("<head>")) {
        html = html.replace("<head>", `<head>${baseTag}`);
      } else {
        html = `${baseTag}${html}`;
      }
      
      // Inject navigation handler
      const script = `
        <script>
          window.addEventListener('click', e => {
            const anchor = e.target.closest('a');
            if (anchor && anchor.href) {
              e.preventDefault();
              window.parent.postMessage({ type: 'PROXY_NAVIGATE', url: anchor.href }, '*');
            }
          });
          
          window.addEventListener('submit', e => {
            e.preventDefault();
            if (e.target.action) {
               window.parent.postMessage({ type: 'PROXY_NAVIGATE', url: e.target.action }, '*');
            }
          });
        </script>
      `;
      
      return html + script;
    } catch (e) {
      console.warn(`Proxy ${gateway} failed:`, e);
      lastError = e as Error;
      continue; // Try next proxy
    }
  }

  // If all failed
  return `
    <html style="background: #000; color: #0f0; font-family: monospace;">
      <body style="display: flex; height: 100vh; align-items: center; justify-content: center; flex-direction: column; text-align: center;">
        <h1 style="font-size: 48px; margin-bottom: 20px; text-shadow: 0 0 10px #0f0;">CONNECTION FAILED</h1>
        <p>ALL_NODES_UNRESPONSIVE</p>
        <p style="opacity: 0.7; margin-top: 20px;">Target: ${targetUrl}</p>
        <div style="border: 1px solid #0f0; padding: 20px; margin-top: 20px; text-align: left;">
          <p>Trace:</p>
          <p>Last Error: ${lastError?.message || "Unknown Error"}</p>
          <p>Note: Some sites block cross-origin requests completely.</p>
        </div>
        <button onclick="window.location.reload()" style="background: #0f0; color: #000; border: none; padding: 10px 20px; margin-top: 20px; cursor: pointer; font-family: monospace; font-weight: bold;">RETRY CONNECTION</button>
      </body>
    </html>
  `;
}