import { useState } from "react";
import { History, Bookmark, MoreVertical, Trash2, Lock, Wifi } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";

interface BrowserControlsProps {
  onHistoryClick: () => void;
  onBookmarkClick: () => void;
  onSettingsClick: () => void;
  privateMode: boolean;
  onPrivateModeToggle: (enabled: boolean) => void;
  onClearHistory: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
}

export function BrowserControls({
  onHistoryClick,
  onBookmarkClick,
  onSettingsClick,
  privateMode,
  onPrivateModeToggle,
  onClearHistory,
  isBookmarked,
  onToggleBookmark
}: BrowserControlsProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="p-2 rounded hover:bg-[#1a1a1a] text-gray-400 hover:text-white transition-colors">
          <MoreVertical size={18} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-[#0a0a0a] border-[#1a1a1a] text-gray-200">
        <DropdownMenuLabel>Browser Controls</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-[#1a1a1a]" />
        
        <DropdownMenuItem onClick={onToggleBookmark} className="cursor-pointer hover:bg-[#1a1a1a]">
          <Bookmark size={16} className={`mr-2 ${isBookmarked ? 'fill-emerald-500 text-emerald-500' : ''}`} />
          {isBookmarked ? 'Remove Bookmark' : 'Bookmark This Site'}
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={onHistoryClick} className="cursor-pointer hover:bg-[#1a1a1a]">
          <History size={16} className="mr-2" />
          View History
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={onBookmarkClick} className="cursor-pointer hover:bg-[#1a1a1a]">
          <Bookmark size={16} className="mr-2" />
          View Bookmarks
        </DropdownMenuItem>
        
        <DropdownMenuSeparator className="bg-[#1a1a1a]" />
        
        <DropdownMenuCheckboxItem 
          checked={privateMode}
          onCheckedChange={onPrivateModeToggle}
          className="cursor-pointer hover:bg-[#1a1a1a]"
        >
          <Lock size={16} className="mr-2" />
          Private Mode
        </DropdownMenuCheckboxItem>
        
        <DropdownMenuSeparator className="bg-[#1a1a1a]" />
        
        <DropdownMenuItem onClick={onClearHistory} className="text-red-400 hover:text-red-300 cursor-pointer hover:bg-red-500/10">
          <Trash2 size={16} className="mr-2" />
          Clear History
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={onSettingsClick} className="cursor-pointer hover:bg-[#1a1a1a]">
          <Wifi size={16} className="mr-2" />
          Settings
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}