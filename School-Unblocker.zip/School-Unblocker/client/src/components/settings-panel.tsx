import { motion } from "framer-motion";
import { X } from "lucide-react";
import { USER_AGENTS } from "@/lib/user-agents";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedUserAgent: string;
  onUserAgentChange: (ua: string) => void;
}

export function SettingsPanel({ isOpen, onClose, selectedUserAgent, onUserAgentChange }: SettingsPanelProps) {
  return (
    <>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 z-40"
        />
      )}
      
      <motion.div
        initial={{ y: 400 }}
        animate={{ y: isOpen ? 0 : 400 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed bottom-0 left-0 right-0 bg-[#0a0a0a] border-t border-[#1a1a1a] z-50 rounded-t-lg max-h-[80vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="sticky top-0 flex items-center justify-between p-4 border-b border-[#1a1a1a] bg-[#0a0a0a]">
          <h2 className="text-emerald-400 font-mono font-bold tracking-wide">SETTINGS</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-[#1a1a1a] rounded transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Settings Content */}
        <div className="p-6 space-y-6">
          {/* User Agent Selection */}
          <div>
            <label className="block text-emerald-500 font-mono text-sm mb-3 tracking-wide">
              // USER AGENT SPOOFING
            </label>
            <select
              value={selectedUserAgent}
              onChange={(e) => onUserAgentChange(e.target.value)}
              className="w-full bg-[#1a1a1a] border border-[#333] text-gray-200 font-mono text-sm rounded px-3 py-2 focus:border-emerald-500 transition-colors"
            >
              {USER_AGENTS.map(ua => (
                <option key={ua.name} value={ua.value}>
                  {ua.name}
                </option>
              ))}
            </select>
            <p className="text-gray-500 font-mono text-xs mt-2">
              Helps bypass some website filters by changing browser identification
            </p>
          </div>

          {/* Info Section */}
          <div className="border-t border-[#1a1a1a] pt-6">
            <h3 className="text-emerald-500 font-mono text-xs tracking-widest mb-4">
              ABOUT VOIDWALKER
            </h3>
            <div className="space-y-2 text-gray-400 text-xs font-mono leading-relaxed">
              <p>Status: ACTIVE</p>
              <p>Proxy: Multi-Node</p>
              <p>Encryption: Client-Side</p>
              <p>Session: Persistent</p>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}