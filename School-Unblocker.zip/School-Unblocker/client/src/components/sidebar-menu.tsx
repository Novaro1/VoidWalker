import { motion } from "framer-motion";
import { X } from "lucide-react";

interface MenuItem {
  title: string;
  icon?: string;
  onClick: () => void;
}

interface SidebarMenuProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  items: MenuItem[];
  emptyMessage?: string;
}

export function SidebarMenu({ isOpen, onClose, title, items, emptyMessage = "Empty" }: SidebarMenuProps) {
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 z-40"
        />
      )}
      
      {/* Sidebar */}
      <motion.div
        initial={{ x: -400 }}
        animate={{ x: isOpen ? 0 : -400 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed left-0 top-0 h-screen w-96 bg-[#0a0a0a] border-r border-[#1a1a1a] z-50 flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#1a1a1a]">
          <h2 className="text-emerald-400 font-mono font-bold tracking-wide">{title}</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-[#1a1a1a] rounded transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {items.length === 0 ? (
            <div className="p-6 text-center text-gray-500 font-mono text-sm">
              {emptyMessage}
            </div>
          ) : (
            <div className="divide-y divide-[#1a1a1a]">
              {items.map((item, i) => (
                <button
                  key={i}
                  onClick={() => {
                    item.onClick();
                    onClose();
                  }}
                  className="w-full text-left p-4 hover:bg-[#1a1a1a] transition-colors group flex items-center gap-3"
                >
                  {item.icon && <img src={item.icon} className="w-5 h-5 opacity-70" />}
                  <span className="text-gray-300 group-hover:text-emerald-400 font-mono text-sm truncate">
                    {item.title}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </>
  );
}