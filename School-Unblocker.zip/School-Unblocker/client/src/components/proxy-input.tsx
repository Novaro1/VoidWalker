import { useState } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowRight, Terminal } from "lucide-react";

export function ProxyInput() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setLoading(true);
    // Navigate to the browser page with the URL
    setTimeout(() => {
      setLocation(`/browser?url=${encodeURIComponent(url)}`);
    }, 800);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl relative group">
      <div className="absolute -inset-1 bg-gradient-to-r from-[hsl(120,100%,50%)] to-[hsl(280,100%,50%)] rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200" />
      
      <div className="relative flex items-center bg-black border border-[hsl(120,100%,20%)] rounded-lg p-2 shadow-2xl">
        <div className="pl-4 pr-2 text-[hsl(120,100%,50%)] animate-pulse">
          <Terminal size={24} />
        </div>
        
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="ENTER TARGET SYSTEM URL..."
          className="flex-1 bg-transparent border-none text-[hsl(120,100%,50%)] placeholder-[hsl(120,50%,30%)] focus:ring-0 text-lg font-mono tracking-wider h-12 outline-none"
          autoFocus
          data-testid="input-proxy-url"
        />

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          type="submit"
          disabled={loading}
          className="bg-[hsl(120,100%,20%)] hover:bg-[hsl(120,100%,30%)] text-[hsl(120,100%,50%)] px-6 py-2 rounded border border-[hsl(120,100%,50%)] font-display uppercase tracking-widest transition-colors flex items-center gap-2"
          data-testid="button-launch"
        >
          {loading ? "INITIALIZING..." : "EXECUTE"}
          {!loading && <ArrowRight size={16} />}
        </motion.button>
      </div>
      
      <div className="mt-2 flex justify-between text-[hsl(120,50%,30%)] text-xs font-mono uppercase">
        <span>Status: Online</span>
        <span>Secure Connection: Active</span>
      </div>
    </form>
  );
}