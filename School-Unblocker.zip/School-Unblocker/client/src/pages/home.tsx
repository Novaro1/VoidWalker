import { motion } from "framer-motion";
import { ProxyInput } from "@/components/proxy-input";
import gridBg from "@assets/generated_images/dark_digital_void_grid_background.png";

export default function Home() {
  return (
    <div 
      className="min-h-screen w-full flex flex-col items-center justify-center relative overflow-hidden p-4"
      style={{
        backgroundImage: `url(${gridBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-black/80 backdrop-blur-[2px]" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 w-full max-w-4xl flex flex-col items-center gap-12"
      >
        <div className="text-center space-y-4">
          <motion.h1 
            className="text-7xl md:text-9xl font-display font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-[hsl(120,100%,50%)] glitch-text"
            data-text="VOIDWALKER"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 100 }}
          >
            VOIDWALKER
          </motion.h1>
          <p className="text-[hsl(120,100%,50%)] font-mono tracking-[0.2em] text-sm md:text-base uppercase opacity-80">
            // UNRESTRICTED ACCESS PROTOCOL V1.0
          </p>
        </div>

        <ProxyInput />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-3xl mt-12 text-[hsl(120,100%,50%)]">
          {[
            { title: "ANONYMOUS", desc: "Digital footprint erased." },
            { title: "UNBLOCKED", desc: "Firewall penetration active." },
            { title: "ENCRYPTED", desc: "Military-grade tunneling." }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + (i * 0.1) }}
              className="border border-[hsl(120,100%,20%)] bg-black/50 p-4 rounded backdrop-blur-sm hover:bg-[hsl(120,100%,10%)] transition-colors cursor-crosshair group"
            >
              <h3 className="font-display text-lg mb-2 group-hover:text-white transition-colors">[{item.title}]</h3>
              <p className="font-mono text-xs opacity-60">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[hsl(120,100%,50%)] to-transparent opacity-50" />
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[hsl(280,100%,50%)] to-transparent opacity-50" />
      <div className="absolute top-4 left-4 font-mono text-xs text-[hsl(120,100%,30%)]">
        SYS.ROOT.USER_ID: 0x93F2
      </div>
      <div className="absolute bottom-4 right-4 font-mono text-xs text-[hsl(120,100%,30%)] animate-pulse">
        CONNECTING_TO_NODE...
      </div>
    </div>
  );
}