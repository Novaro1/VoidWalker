import { useLocation, useSearch } from "wouter";
import { useEffect, useState, useRef } from "react";
import { normalizeUrl, fetchProxyContent } from "@/lib/proxy";
import { CLOAK_PRESETS, setCloak, resetCloak } from "@/lib/cloaking";
import { saveState, loadState, addToHistory, getHistory, clearHistory, addBookmark, removeBookmark, getBookmarks, isBookmarked } from "@/lib/storage";
import { injectUserAgent } from "@/lib/user-agents";
import { BrowserControls } from "@/components/browser-controls";
import { SidebarMenu } from "@/components/sidebar-menu";
import { SettingsPanel } from "@/components/settings-panel";
import { 
  ArrowLeft, RefreshCw, Globe, Lock, Plus, X, 
  Shield, Eye, EyeOff, AlertTriangle, Settings
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface Tab {
  id: string;
  url: string;
  title: string;
  content: string;
  loading: boolean;
  history: string[];
}

export default function Browser() {
  const [location, setLocation] = useLocation();
  const search = useSearch();
  
  // Tab State
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [isCloaked, setIsCloaked] = useState(false);
  const [currentCloak, setCurrentCloak] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [privateMode, setPrivateMode] = useState(false);
  const [selectedUserAgent, setSelectedUserAgent] = useState("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
  const [showHistory, setShowHistory] = useState(false);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [historyList, setHistoryList] = useState<string[]>([]);
  const [bookmarksList, setBookmarksList] = useState<any[]>([]);

  // Load saved state on mount
  useEffect(() => {
    const saved = loadState();
    if (saved && saved.tabs.length > 0) {
      // Restore tabs from saved state
      const restoredTabs: Tab[] = saved.tabs.map(t => ({
        ...t,
        content: "",
        loading: false,
        history: [t.url]
      }));
      
      setTabs(restoredTabs);
      setActiveTabId(saved.activeTabId || restoredTabs[0].id);
      
      if (saved.cloakEnabled && saved.cloakPreset) {
        setCloak(saved.cloakPreset);
        setIsCloaked(true);
        setCurrentCloak(saved.cloakPreset);
      }
      
      // Load content for the active tab
      const activeTab = restoredTabs.find(t => t.id === (saved.activeTabId || restoredTabs[0].id));
      if (activeTab) {
        loadTabContent(activeTab.id, activeTab.url);
      }
    } else {
      // No saved state, check URL params
      const params = new URLSearchParams(search);
      const initialUrl = params.get("url");
      if (initialUrl) {
        createNewTab(normalizeUrl(initialUrl));
      } else {
        createNewTab("https://google.com");
      }
    }
    setInitialized(true);
  }, []);

  // Auto-save state whenever it changes
  useEffect(() => {
    if (!initialized) return;
    
    saveState({
      tabs: tabs.map(t => ({ id: t.id, url: t.url, title: t.title })),
      activeTabId,
      cloakEnabled: isCloaked,
      cloakPreset: currentCloak,
      history: [],
      bookmarks: [],
      privateMode
    });
  }, [tabs, activeTabId, isCloaked, currentCloak, initialized, privateMode]);

  // Load history when history sidebar opens
  useEffect(() => {
    if (showHistory) {
      setHistoryList(getHistory());
    }
  }, [showHistory]);

  // Load bookmarks when bookmarks sidebar opens
  useEffect(() => {
    if (showBookmarks) {
      setBookmarksList(getBookmarks());
    }
  }, [showBookmarks]);

  const createNewTab = (urlInput: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    const url = normalizeUrl(urlInput);
    
    const newTab: Tab = {
      id,
      url,
      title: "New Tab",
      content: "",
      loading: true,
      history: [url]
    };

    setTabs(prev => [...prev, newTab]);
    setActiveTabId(id);
    loadTabContent(id, url);
  };

  const closeTab = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    
    if (activeTabId === id && newTabs.length > 0) {
      setActiveTabId(newTabs[newTabs.length - 1].id);
    } else if (newTabs.length === 0) {
      setLocation("/");
    }
  };

  const updateTab = (id: string, updates: Partial<Tab>) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const loadTabContent = async (id: string, url: string) => {
    updateTab(id, { loading: true, url, title: url }); // Optimistic update
    addToHistory(url, privateMode);
    
    let content = await fetchProxyContent(url);
    
    // Inject user agent
    content = injectUserAgent(content, selectedUserAgent);
    
    // Extract title from fetched content if possible
    const titleMatch = content.match(/<title>(.*?)<\/title>/);
    const pageTitle = titleMatch ? titleMatch[1] : url;

    updateTab(id, { 
      content, 
      loading: false, 
      title: pageTitle 
    });
  };

  const handleNavigate = (url: string) => {
    if (activeTabId) {
      loadTabContent(activeTabId, url);
    }
  };

  // Handle messages from iframes
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data && e.data.type === 'PROXY_NAVIGATE' && e.data.url && activeTabId) {
        loadTabContent(activeTabId, e.data.url);
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [activeTabId]);

  const activeTab = tabs.find(t => t.id === activeTabId);

  const toggleCloak = (presetName: string) => {
    setCloak(presetName);
    setIsCloaked(true);
    setCurrentCloak(presetName);
  };

  const disableCloak = () => {
    resetCloak();
    setIsCloaked(false);
    setCurrentCloak(null);
  };

  const panic = () => {
    window.location.href = "https://classroom.google.com";
  };

  const handlePrivateMode = (enabled: boolean) => {
    setPrivateMode(enabled);
  };

  const handleToggleBookmark = () => {
    if (!activeTab) return;
    if (isBookmarked(activeTab.url)) {
      const bookmark = bookmarksList.find(b => b.url === activeTab.url);
      if (bookmark) removeBookmark(bookmark.id);
    } else {
      addBookmark(activeTab.url, activeTab.title);
    }
    setBookmarksList(getBookmarks());
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0a0a0a] overflow-hidden font-sans text-white">
      {/* Sidebars */}
      <SidebarMenu 
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        title="HISTORY"
        items={historyList.map(url => ({ title: url, onClick: () => handleNavigate(url) }))}
        emptyMessage="NO HISTORY YET"
      />

      <SidebarMenu 
        isOpen={showBookmarks}
        onClose={() => setShowBookmarks(false)}
        title="BOOKMARKS"
        items={bookmarksList.map(b => ({ title: b.title, onClick: () => handleNavigate(b.url) }))}
        emptyMessage="NO BOOKMARKS YET"
      />

      <SettingsPanel 
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        selectedUserAgent={selectedUserAgent}
        onUserAgentChange={setSelectedUserAgent}
      />

      {/* Top Bar: Tabs & Controls */}
      <div className="flex items-end gap-1 px-2 pt-2 bg-[#050505] border-b border-[#1a1a1a] select-none">
        {/* Home Button */}
        <button 
          onClick={() => setLocation("/")}
          className="p-2 mb-1 hover:bg-[#1a1a1a] rounded text-emerald-500 transition-colors"
          title="Exit to Home"
        >
          <ArrowLeft size={18} />
        </button>

        {/* Tab List */}
        <div className="flex-1 flex overflow-x-auto no-scrollbar items-end gap-1">
          <AnimatePresence>
            {tabs.map(tab => (
              <motion.div
                key={tab.id}
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                onClick={() => setActiveTabId(tab.id)}
                className={`
                  group relative flex items-center gap-2 px-3 py-2 min-w-[150px] max-w-[200px] rounded-t-lg cursor-pointer transition-colors border-t border-x border-transparent
                  ${activeTabId === tab.id 
                    ? "bg-[#1a1a1a] border-[#2a2a2a] text-emerald-400" 
                    : "bg-[#0a0a0a] hover:bg-[#111] text-gray-400 hover:text-gray-200"}
                `}
              >
                {tab.loading ? (
                   <RefreshCw size={12} className="animate-spin shrink-0" />
                ) : (
                   <Globe size={12} className="shrink-0" />
                )}
                <span className="text-xs truncate flex-1 font-mono">{tab.title}</span>
                <button 
                  onClick={(e) => closeTab(e, tab.id)}
                  className="opacity-0 group-hover:opacity-100 hover:bg-red-500/20 hover:text-red-400 rounded p-0.5 transition-all"
                >
                  <X size={12} />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          
          <button 
            onClick={() => createNewTab("https://google.com")}
            className="p-2 mb-1 hover:bg-[#1a1a1a] rounded-full text-gray-500 hover:text-emerald-500 transition-colors"
          >
            <Plus size={18} />
          </button>
        </div>

        {/* System Tools */}
        <div className="flex items-center gap-1 mb-1 px-2 border-l border-[#1a1a1a] ml-2">
           <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={`p-2 rounded transition-colors ${isCloaked ? 'text-purple-400 bg-purple-400/10' : 'text-gray-400 hover:text-white'}`}>
                {isCloaked ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-[#0a0a0a] border-[#1a1a1a] text-gray-200">
              <DropdownMenuLabel>Tab Disguise</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-[#1a1a1a]" />
              {CLOAK_PRESETS.map(preset => (
                <DropdownMenuItem 
                  key={preset.name}
                  onClick={() => toggleCloak(preset.name)}
                  className="cursor-pointer hover:bg-[#1a1a1a] focus:bg-[#1a1a1a]"
                >
                  <img src={preset.icon} className="w-4 h-4 mr-2" />
                  {preset.name}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator className="bg-[#1a1a1a]" />
              <DropdownMenuItem onClick={disableCloak} className="text-red-400 hover:text-red-300 cursor-pointer">
                Reset Disguise
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <BrowserControls 
            onHistoryClick={() => setShowHistory(true)}
            onBookmarkClick={() => setShowBookmarks(true)}
            onSettingsClick={() => setShowSettings(true)}
            privateMode={privateMode}
            onPrivateModeToggle={handlePrivateMode}
            onClearHistory={clearHistory}
            isBookmarked={activeTab ? isBookmarked(activeTab.url) : false}
            onToggleBookmark={handleToggleBookmark}
          />

          <button 
            onClick={panic}
            className="p-2 rounded text-red-500 hover:bg-red-500/10 transition-colors"
            title="PANIC BUTTON (Exit to Classroom)"
          >
            <AlertTriangle size={18} />
          </button>

          {privateMode && (
            <div className="ml-2 px-2 py-1 bg-red-500/10 border border-red-500/30 rounded text-red-400 font-mono text-xs">
              PRIVATE
            </div>
          )}
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="flex items-center gap-3 p-2 bg-[#1a1a1a] border-b border-[#2a2a2a]">
        <div className="flex-1 flex items-center bg-[#0a0a0a] border border-[#333] rounded px-3 py-1.5 gap-3 focus-within:border-emerald-500/50 transition-colors">
          <div className="text-emerald-500/50">
            <Lock size={12} />
          </div>
          <input 
            value={activeTab?.url || ""}
            onChange={(e) => {
               if(activeTabId) updateTab(activeTabId, { url: e.target.value });
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && activeTab?.url) {
                handleNavigate(activeTab.url);
              }
            }}
            className="flex-1 bg-transparent border-none outline-none text-emerald-500 font-mono text-sm placeholder-emerald-900"
            placeholder="Enter URL..."
          />
          {activeTab?.loading && <RefreshCw size={14} className="animate-spin text-emerald-500" />}
        </div>
      </div>

      {/* Viewport Area */}
      <div className="flex-1 relative bg-white">
        {tabs.map(tab => (
          <div 
            key={tab.id} 
            className={`absolute inset-0 w-full h-full bg-white ${activeTabId === tab.id ? 'z-10 visible' : 'z-0 invisible'}`}
          >
            {tab.content ? (
               <iframe 
                srcDoc={tab.content}
                className="w-full h-full border-none"
                sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
                title={tab.title}
              />
            ) : (
               <div className="w-full h-full bg-[#0a0a0a] flex items-center justify-center">
                 <div className="flex flex-col items-center gap-4 animate-pulse">
                    <div className="w-12 h-12 border-4 border-emerald-900 border-t-emerald-500 rounded-full animate-spin" />
                    <div className="text-emerald-500 font-mono text-sm tracking-widest">CONNECTING TO NODE...</div>
                 </div>
               </div>
            )}
          </div>
        ))}
        
        {tabs.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-[#0a0a0a] text-gray-500 font-mono">
            OPEN A NEW TAB TO BEGIN
          </div>
        )}
      </div>
    </div>
  );
}